// Phase 4: rebuilt on DataTable with URL-synced filters, server-shaped paging
// and sort, and a user detail page. The pending/approve/block/unblock flow is
// gone — status is Active/Inactive, set in the mobile app; this page is read
// and delete only (View, Export, Delete per row; bulk delete via selection).
import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import UserFilters from '../components/UserFilters';
import * as usersRepo from '../data/usersRepository';
import { path, ROUTES } from '../../../core/config/routes';
import { formatDate, formatRelative } from '../../../core/logic/format';
import { composeSection } from '../../../core/logic/validation';
import ConfirmDialog from '../../../shared/components/ConfirmDialog';
import DataTable from '../../../shared/components/DataTable';
import { Icon } from '../../../shared/components/Icon';
import Pager from '../../../shared/components/Pager';
import PageHeader from '../../../shared/components/PageHeader';
import { SkeletonTable } from '../../../shared/components/Skeleton';
import Tabs from '../../../shared/components/Tabs';
import { Avatar, Badge, Card, Toast } from '../../../shared/components/ui';
import EmptyState from '../../../shared/components/EmptyState';
import { useAsync, usePagination, useQueryState, useToast } from '../../../shared/hooks';
import { downloadCsv } from '../../../shared/utils/csv';

const TABS = [
  { key: 'All', label: 'All' },
  { key: 'Student', label: 'Students' },
  { key: 'Instructor', label: 'Instructors' },
];
const PAGE_SIZE = 10;

const DEFAULTS = {
  tab: 'All',
  page: 1,
  sort: 'name',
  order: 'asc',
  q: '',
  course: 'All',
  year: 'All',
  section: 'All',
  department: 'All',
  status: 'All',
};
const RESET_PAGE_ON = ['tab', 'q', 'course', 'year', 'section', 'department', 'status'];

const CSV_HEADERS = ['Name', 'Email', 'Role', 'Course', 'Year', 'Section', 'Department', 'Status', 'Joined', 'Last active'];
const toCsvRow = (u) => [u.name, u.email, u.role, u.course ?? '', u.year ?? '', u.section ?? '', u.department ?? '', u.status, formatDate(u.joinedAt), formatDate(u.lastActiveAt)];
const exportCsv = (rows, filename = 'studia-users.csv') => downloadCsv(filename, CSV_HEADERS, rows.map(toCsvRow));

export default function Users() {
  const [query, setQuery] = useQueryState(DEFAULTS, { resetPageOn: RESET_PAGE_ON });
  const [selected, setSelected] = useState(new Set());
  const [deleteIds, setDeleteIds] = useState(null);
  const [busy, setBusy] = useState(false);
  const { toast, showToast, showError, clearToast } = useToast();

  const params = useMemo(
    () => ({
      page: query.page,
      pageSize: PAGE_SIZE,
      sort: query.sort,
      order: query.order,
      q: query.q,
      filters: {
        role: query.tab === 'All' ? undefined : query.tab,
        course: query.course,
        year: query.year,
        section: query.section,
        department: query.department,
        status: query.status,
      },
    }),
    [query]
  );

  const { data, error, loading, reload } = useAsync(
    (signal) => usersRepo.getUsers(params, { signal }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [JSON.stringify(params)]
  );

  const rows = data?.data ?? [];
  const pagination = usePagination({ page: query.page, pageSize: PAGE_SIZE, total: data?.meta.total ?? 0 });
  const selectedRows = rows.filter((u) => selected.has(u.id));
  const deleteTargets = rows.filter((u) => deleteIds?.includes(u.id));

  const runDelete = async () => {
    if (!deleteIds?.length) return;
    setBusy(true);
    try {
      await usersRepo.deleteUsers(deleteIds);
      showToast(`${deleteIds.length} user${deleteIds.length === 1 ? '' : 's'} deleted.`);
      setSelected((prev) => {
        const next = new Set(prev);
        deleteIds.forEach((id) => next.delete(id));
        return next;
      });
      setDeleteIds(null);
      reload();
    } catch (e) {
      showError(e);
    } finally {
      setBusy(false);
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'Name',
      sortable: true,
      primary: true,
      render: (u) => (
        <div className="name-cell">
          <Avatar name={u.name} />
          <div>
            <strong>{u.name}</strong>
            <div className="muted small">{u.email}</div>
          </div>
        </div>
      ),
    },
    { key: 'role', header: 'Role', sortable: true, render: (u) => <Badge>{u.role}</Badge> },
    {
      key: 'course',
      header: 'Course / Dept',
      render: (u) => (u.role === 'Instructor' ? `Dept. ${u.department}` : composeSection(u.course, u.year, u.section)),
    },
    { key: 'status', header: 'Status', sortable: true, render: (u) => <Badge>{u.status}</Badge> },
    { key: 'joinedAt', header: 'Joined', sortable: true, render: (u) => formatDate(u.joinedAt) },
    { key: 'lastActiveAt', header: 'Last active', sortable: true, render: (u) => formatRelative(u.lastActiveAt) },
  ];

  return (
    <>
      <PageHeader
        title="Users"
        subtitle="Students and instructors registered in the mobile app. Accounts are created there, so this page is read and delete only."
        actions={
          <>
            <button type="button" className="btn btn-ghost" disabled={!rows.length} onClick={() => exportCsv(rows)}>
              <Icon.Download /> Export CSV
            </button>
            <button
              type="button"
              className="btn btn-red"
              disabled={!selectedRows.length || busy}
              onClick={() => setDeleteIds(selectedRows.map((u) => u.id))}
            >
              <Icon.Trash /> Delete ({selectedRows.length})
            </button>
          </>
        }
      />

      <Tabs
        aria-label="Filter by role"
        items={TABS}
        value={query.tab}
        onChange={(tab) => setQuery({ tab })}
        controls="users-results"
      />

      <UserFilters query={query} onChange={setQuery} />

      <Card id="users-results" role="tabpanel" aria-labelledby={`tab-${query.tab}`}>
        {loading && <SkeletonTable rows={6} cols={6} />}

        {!loading && error && (
          <EmptyState
            tone="error"
            title="Users could not load"
            message={error.message}
            action={
              <button type="button" className="btn btn-primary" onClick={reload}>
                Try again
              </button>
            }
          />
        )}

        {!loading && !error && (
          <>
            <DataTable
              columns={columns}
              rows={rows}
              sort={{ key: query.sort, order: query.order }}
              onSortChange={({ key, order }) => setQuery({ sort: key, order })}
              selectable
              selectedIds={selected}
              onSelectedChange={setSelected}
              rowLabel={(u) => u.name}
              caption="Users"
              emptyTitle="No users found"
              emptyMessage="Try a different filter or search term."
              renderActions={(u) => (
                <>
                  <Link to={path(ROUTES.userDetail, { id: u.id })} className="link-btn">
                    <Icon.Eye /> View
                  </Link>
                  <button type="button" className="link-btn" onClick={() => exportCsv([u], `studia-user-${u.id}.csv`)}>
                    <Icon.Download /> Export
                  </button>
                  <button type="button" className="link-btn warn" onClick={() => setDeleteIds([u.id])}>
                    <Icon.Trash /> Delete
                  </button>
                </>
              )}
            />
            {rows.length > 0 && <Pager pagination={pagination} onPageChange={(page) => setQuery({ page })} />}
          </>
        )}
      </Card>

      <ConfirmDialog
        open={!!deleteIds}
        title={`Delete ${deleteIds?.length ?? 0} user${(deleteIds?.length ?? 0) === 1 ? '' : 's'}?`}
        confirmWord="DELETE"
        confirmLabel="Delete permanently"
        busy={busy}
        onConfirm={runDelete}
        onClose={() => setDeleteIds(null)}
      >
        {deleteTargets.length === 1 ? (
          <>
            <b>{deleteTargets[0].name}</b> will be
          </>
        ) : (
          `${deleteIds?.length ?? 0} users will be`
        )}{' '}
        permanently removed, together with their submissions and AI history. This cannot be undone.
      </ConfirmDialog>

      <Toast message={toast.message} kind={toast.kind} onDone={clearToast} />
    </>
  );
}
