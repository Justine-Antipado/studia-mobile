// notifications-screen.tsx — one implementation, role-aware via `role` (feed comes from
// notificationRepository.listByRole(role)).
import { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import type { Role } from "@/core/types/role";
import {
  useMarkAllNotificationsRead,
  useMarkNotificationRead,
  useNotifications,
} from "@/features/shared-screens/hooks/use-notifications";
import { Badge } from "@/shared/components/ui/badge";
import { ListRow } from "@/shared/components/ui/list-row";
import { ListState } from "@/shared/components/ui/list-state";
import { PageTitle } from "@/shared/components/ui/page-title";
import { Screen } from "@/shared/components/ui/screen";
import { SegmentedTabs } from "@/shared/components/ui/segmented-tabs";
import { C } from "@/shared/constants/studia-colors";
import { SPACE } from "@/shared/constants/tokens";

const FILTERS = ["All", "Unread"] as const;

export function NotificationsScreen({ role }: { role: Role }) {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const { data, loading, error, refetch } = useNotifications(role);
  const items = data ?? [];
  const unreadCount = items.filter((n) => n.unread).length;
  const shown = filter === "Unread" ? items.filter((n) => n.unread) : items;

  const markRead = useMarkNotificationRead(role);
  const markAllRead = useMarkAllNotificationsRead(role);

  return (
    <Screen role={role} scope={`${role}/notifications`}>
      <View style={{ gap: SPACE.lg }}>
        <PageTitle
          title="Notifications"
          trailing={
            unreadCount > 0 ? (
              <Pressable onPress={() => void markAllRead.run(undefined)} hitSlop={8} accessibilityRole="button">
                <Text style={s.markAll}>Mark all read</Text>
              </Pressable>
            ) : undefined
          }
        />

        <SegmentedTabs items={FILTERS} value={filter} onChange={setFilter} />

        <ListState
          loading={loading}
          error={error}
          empty={!loading && shown.length === 0}
          onRetry={refetch}
          emptyIcon="notifications-off-outline"
          emptyTitle="You're all caught up"
          emptyMessage="New notifications will show up here."
        >
          <View style={{ gap: SPACE.md }}>
            {shown.map((n) => (
              <ListRow
                key={n.id}
                icon={n.icon}
                eyebrow={n.tag}
                title={n.title}
                subtitle={`${n.meta} · ${n.time}`}
                trailing={n.unread ? <View style={s.unreadDot} /> : <Badge label={n.tag} tone={n.tone} />}
                onPress={() => void markRead.run(n.id)}
              />
            ))}
          </View>
        </ListState>
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  markAll: { color: C.primary, fontSize: 12.5, fontFamily: "Poppins_600SemiBold" },
  unreadDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: C.primary },
});
