# instructor components

Instructor-only components built on the shared UI kit (`shared/components/ui`). `class-detail/`
holds the five class-detail tabs (Stream, Materials, Assessments, People, Grades). `instructor-ui.tsx`
was removed in P3 — screens import primitives from `shared/components/ui` directly.
