// classes-screen.tsx — Classes tab: list + create class.
import { useRouter } from "expo-router";
import { View } from "react-native";

import { ActionButton, ListRow, ListState, PageTitle } from "@/shared/components/ui";
import { Screen } from "@/shared/components/ui/screen";
import { SPACE } from "@/shared/constants/tokens";
import { plural } from "@/features/instructor/logic/format";
import { useInstructorClasses } from "@/features/instructor/hooks/use-classes";

export default function InstructorClassesScreen() {
  const router = useRouter();
  const { data, loading, error, refetch } = useInstructorClasses();
  const classes = data ?? [];

  return (
    <Screen role="instructor" scope="instructor/classes">
      <View style={{ gap: SPACE.lg }}>
        <PageTitle
          title="Classes"
          trailing={<ActionButton label="Create" icon="add" onPress={() => router.push("/instructor/create-class")} />}
        />

        <ListState
          loading={loading}
          error={error}
          empty={!loading && classes.length === 0}
          onRetry={refetch}
          emptyIcon="school-outline"
          emptyTitle="No classes yet"
          emptyMessage="Create your first class to get started."
        >
          <View style={{ gap: SPACE.md }}>
            {classes.map((c) => (
              <ListRow
                key={c.id}
                icon="book-outline"
                eyebrow={`${c.code} · ${c.section}`}
                title={c.title}
                subtitle={`${plural(c.studentCount, "student")} · Code: ${c.joinCode}`}
                onPress={() => router.push({ pathname: "/instructor/class-detail", params: { id: c.id } })}
              />
            ))}
          </View>
        </ListState>
      </View>
    </Screen>
  );
}
