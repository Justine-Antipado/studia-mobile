// grading-screen.tsx — submissions waiting for review, oldest first, optionally filtered by quiz.
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { View } from "react-native";

import { Chip, ListRow, ListState, PageTitle } from "@/shared/components/ui";
import { Screen } from "@/shared/components/ui/screen";
import { SPACE } from "@/shared/constants/tokens";
import { useRouteId } from "@/core/logic/route-params";
import { useSafeBack } from "@/shared/hooks/use-safe-back";
import { plural, timeAgo } from "@/features/instructor/logic/format";
import { useAllSubmissions } from "@/features/instructor/hooks/use-submissions";

export default function GradingScreen() {
  const router = useRouter();
  const goBack = useSafeBack("/instructor/assessments");
  const presetQuizId = useRouteId("quizId");
  const { data, loading, error, refetch } = useAllSubmissions();
  const [filter, setFilter] = useState<string | null>(presetQuizId);

  const pending = useMemo(
    () => (data ?? []).filter((x) => x.score === null).sort((a, b) => a.submittedAt.localeCompare(b.submittedAt)),
    [data],
  );

  const quizzes = useMemo(() => {
    const map = new Map<string, string>();
    pending.forEach((x) => map.set(x.quizId, `${x.classCode} · ${x.quizTitle}`));
    return Array.from(map, ([id, label]) => ({ id, label }));
  }, [pending]);

  // If the filtered quiz has nothing left to grade, fall back to "All".
  const active = quizzes.some((q) => q.id === filter) ? filter : null;
  const visible = active ? pending.filter((x) => x.quizId === active) : pending;

  return (
    <Screen role="instructor" scope="instructor/grading">
      <PageTitle title="Needs Grading" subtitle={`${plural(pending.length, "submission")} waiting, oldest first`} onBack={goBack} />

      <ListState loading={loading} error={error} onRetry={refetch} empty={!loading && pending.length === 0} emptyIcon="checkmark-done-outline" emptyTitle="All caught up" emptyMessage="Every submission has been graded.">
        <View style={{ gap: SPACE.md }}>
          {quizzes.length > 1 ? (
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: SPACE.sm }}>
              <Chip label="All" selected={active === null} onPress={() => setFilter(null)} />
              {quizzes.map((q) => <Chip key={q.id} label={q.label} selected={active === q.id} onPress={() => setFilter(q.id)} />)}
            </View>
          ) : null}

          {visible.map((x) => (
            <ListRow
              key={x.id}
              icon="document-text-outline"
              eyebrow={`${x.classCode} · ${x.quizTitle}`}
              title={x.studentName}
              subtitle={`Submitted ${timeAgo(x.submittedAt)}`}
              onPress={() => router.push({ pathname: "/instructor/grade-submission", params: { id: x.id } })}
            />
          ))}
        </View>
      </ListState>
    </Screen>
  );
}
