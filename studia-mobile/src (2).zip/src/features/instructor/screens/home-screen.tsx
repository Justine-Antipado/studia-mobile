// home-screen.tsx — Instructor Home: greeting, overview numbers, what needs grading, shortcuts.
import { useRouter } from "expo-router";
import { Text, View } from "react-native";

import { EmptyState, ListRow, ListState, QuickAction, SectionHeader, StatCard } from "@/shared/components/ui";
import { Screen } from "@/shared/components/ui/screen";
import { TONES } from "@/shared/constants/studia-colors";
import { SPACE, TYPE } from "@/shared/constants/tokens";
import { greetName, useRoleUser } from "@/core/data/storage/session-store";
import { plural, timeAgo } from "@/features/instructor/logic/format";
import { useInstructorClasses } from "@/features/instructor/hooks/use-classes";
import { useInstructorStats } from "@/features/instructor/hooks/use-stats";

export default function InstructorHomeScreen() {
  const user = useRoleUser("instructor");
  const router = useRouter();
  const classes = useInstructorClasses();
  const stats = useInstructorStats();

  const openGrading = () =>
    router.push(
      stats.data?.nextGrading
        ? { pathname: "/instructor/grading", params: { quizId: stats.data.nextGrading.quizId } }
        : "/instructor/grading",
    );

  return (
    <Screen role="instructor" scope="instructor/home">
      <View style={{ gap: SPACE.xl }}>
        <View>
          <Text style={TYPE.muted}>Welcome back</Text>
          <Text style={TYPE.h1} numberOfLines={2}>
            {user ? greetName(user) : "Instructor"}
          </Text>
        </View>

        <ListState loading={stats.loading} error={null}>
          {stats.data ? (
            <View style={{ gap: SPACE.lg }}>
              <View style={{ flexDirection: "row", gap: SPACE.md }}>
                <StatCard label="Classes" value={stats.data.classCount} onPress={() => router.push("/instructor/classes")} />
                <StatCard label="Students" value={stats.data.studentCount} onPress={() => router.push("/instructor/classes")} />
                <StatCard
                  label="To Grade"
                  value={stats.data.pendingCount}
                  tone={stats.data.pendingCount > 0 ? "orange" : "green"}
                  onPress={openGrading}
                />
              </View>

              {stats.data.nextGrading ? (
                <ListRow
                  icon="document-text-outline"
                  iconBg={TONES.orange.bg}
                  iconColor={TONES.orange.fg}
                  eyebrow="Needs grading"
                  title={`${plural(stats.data.pendingCount, "submission")} waiting`}
                  subtitle={`${stats.data.nextGrading.quizTitle}, ${stats.data.nextGrading.classCode} · Oldest ${timeAgo(stats.data.nextGrading.oldestAt)}`}
                  onPress={openGrading}
                />
              ) : (
                <ListRow
                  icon="checkmark-circle-outline"
                  iconBg={TONES.green.bg}
                  iconColor={TONES.green.fg}
                  title="All caught up"
                  subtitle="No submissions waiting for review."
                  onPress={() => router.push("/instructor/gradebook")}
                />
              )}
            </View>
          ) : null}
        </ListState>

        <View style={{ gap: SPACE.md }}>
          <SectionHeader title="Quick actions" />
          <View style={{ flexDirection: "row", justifyContent: "space-between", flexWrap: "wrap", rowGap: 10 }}>
            <QuickAction icon="people-outline" label="My Classes" tone="primary" onPress={() => router.push("/instructor/classes")} />
            <QuickAction icon="create-outline" label="Create Quiz" tone="blue" onPress={() => router.push("/instructor/create-quiz")} />
            <QuickAction icon="bar-chart-outline" label="Analytics" tone="green" onPress={() => router.push("/instructor/analytics")} />
            <QuickAction icon="sparkles-outline" label="AI Quiz" tone="gold" onPress={() => router.push("/instructor/ai-quiz")} />
          </View>
        </View>

        <View style={{ gap: SPACE.md }}>
          <SectionHeader title="My Classes" action="View All" onAction={() => router.push("/instructor/classes")} />
          <ListState loading={classes.loading} error={classes.error} onRetry={classes.refetch}>
            {(classes.data ?? []).length === 0 ? (
              <EmptyState icon="school-outline" title="No classes yet" message="Classes assigned to you will show up here." />
            ) : (
              <View style={{ gap: SPACE.md }}>
                {(classes.data ?? []).slice(0, 2).map((c) => (
                  <ListRow
                    key={c.id}
                    icon="book-outline"
                    eyebrow={`${c.code} · ${c.section}`}
                    title={c.title}
                    subtitle={plural(c.studentCount, "student")}
                    onPress={() => router.push({ pathname: "/instructor/class-detail", params: { id: c.id } })}
                  />
                ))}
              </View>
            )}
          </ListState>
        </View>
      </View>
    </Screen>
  );
}
