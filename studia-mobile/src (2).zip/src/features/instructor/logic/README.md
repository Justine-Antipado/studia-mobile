# instructor logic

`format.ts` (dates/scores/labels), `validators.ts` (input + file validation), `quiz-validation.ts`
(question/draft validation, score parsing), `ai-quiz-generator.ts` (mock AI Quiz Synthesizer).
