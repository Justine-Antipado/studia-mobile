// validators.ts — input validation/sanitization for every instructor form. Repositories never
// receive raw, untrimmed or oversized input. Route params are validated separately in
// core/logic/route-params.ts.
import type { AttachmentKind } from "@/features/instructor/types/instructor";

export function validateClassTitle(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Enter a class name.";
  if (text.length > 80) return "Keep the name under 80 characters.";
  return null;
}

export function validateClassSection(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Enter a section.";
  if (text.length > 30) return "Keep the section under 30 characters.";
  return null;
}

export function validateClassCode(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Enter a subject code.";
  if (text.length > 15) return "Keep the code under 15 characters.";
  return null;
}

export function validateAnnouncementTitle(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Add a title.";
  if (text.length > 100) return "Keep the title under 100 characters.";
  return null;
}

export function validateAnnouncementBody(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Write something to post.";
  if (text.length > 2000) return "Keep this under 2000 characters.";
  return null;
}

export function validateAssignmentTitle(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Add a title.";
  if (text.length > 100) return "Keep the title under 100 characters.";
  return null;
}

export function validateAssignmentInstructions(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Add instructions for students.";
  if (text.length > 4000) return "Keep this under 4000 characters.";
  return null;
}

export function validatePoints(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Enter the point value.";
  const value = Number(text);
  if (!Number.isFinite(value) || value <= 0) return "Points must be a positive number.";
  if (value > 1000) return "Keep points at or under 1000.";
  return null;
}

export function validateMaterialTitle(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Add a title for this material.";
  if (text.length > 100) return "Keep the title under 100 characters.";
  return null;
}

/** mp4/mov/pdf/ppt(x)/docx only, matching docs/UI-BRIEF's upload whitelist for materials. */
export const ALLOWED_EXTENSIONS: Record<string, AttachmentKind> = {
  pdf: "pdf",
  doc: "doc",
  docx: "doc",
  ppt: "slide",
  pptx: "slide",
  mp4: "video",
  mov: "video",
};

export const MAX_FILE_SIZE_BYTES = 500 * 1024 * 1024;

export type FileCandidate = { name: string; sizeBytes: number };

export function sanitizeFileName(name: string): string {
  return name.replace(/[^A-Za-z0-9 ._-]/g, "_").slice(0, 120);
}

export function validateFile(file: FileCandidate): { error: string | null; kind: AttachmentKind | null } {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const kind = ALLOWED_EXTENSIONS[ext] ?? null;
  if (!kind) return { error: "Allowed files: PDF, Word, PowerPoint, MP4 or MOV.", kind: null };
  if (file.sizeBytes > MAX_FILE_SIZE_BYTES) return { error: "File is larger than 500 MB.", kind: null };
  return { error: null, kind };
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
