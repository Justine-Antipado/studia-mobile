// courses-screen.tsx — list of joined classes + "Join Class" entry point (modal route).
import { useRouter } from "expo-router";
import { useCallback } from "react";
import { FlatList, Text, View } from "react-native";

import { ActionButton, ListState, OfflineBanner } from "@/shared/components/ui";
import { Screen } from "@/shared/components/ui/screen";
import { SPACE, TYPE } from "@/shared/constants/tokens";
import { ClassCard } from "@/features/student/components/class-card";
import { useClasses } from "@/features/student/hooks/use-classes";
import type { StudentClass } from "@/features/student/types/student";

export default function StudentCourses() {
  const router = useRouter();
  const { data, loading, error, refetch } = useClasses();
  const classes = data ?? [];

  const renderItem = useCallback(
    ({ item }: { item: StudentClass }) => (
      <ClassCard item={item} onPress={() => router.push({ pathname: "/student/course-detail", params: { id: item.id } })} />
    ),
    [router],
  );

  return (
    <Screen role="student" scroll={false} scope="student/courses">
      <OfflineBanner />
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
        <Text style={TYPE.h1}>Courses</Text>
      </View>
      <ActionButton label="Join Class" icon="add" onPress={() => router.push("/student/join-class")} />

      <View style={{ flex: 1 }}>
        <ListState
          loading={loading}
          error={error}
          empty={!loading && classes.length === 0}
          onRetry={refetch}
          emptyIcon="book-outline"
          emptyTitle="No classes yet"
          emptyMessage="Join a class with the 6-character code from your instructor."
          emptyActionLabel="Join Class"
          onEmptyAction={() => router.push("/student/join-class")}
        >
          <FlatList
            data={classes}
            keyExtractor={(item) => item.id}
            renderItem={renderItem}
            refreshing={loading}
            onRefresh={refetch}
            ItemSeparatorComponent={() => <View style={{ height: SPACE.md }} />}
            contentContainerStyle={{ paddingBottom: SPACE.xl }}
            showsVerticalScrollIndicator={false}
          />
        </ListState>
      </View>
    </Screen>
  );
}
