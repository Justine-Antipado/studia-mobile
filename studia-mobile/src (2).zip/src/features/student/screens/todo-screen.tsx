// todo-screen.tsx — auto-generated checklist from assignments + quizzes, with filters/sort.
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { FlatList, Pressable, View } from "react-native";

import { Icon, ListState, OfflineBanner, PageTitle, ProgressBar, SegmentedTabs } from "@/shared/components/ui";
import { Screen } from "@/shared/components/ui/screen";
import { C } from "@/shared/constants/studia-colors";
import { HIT_SLOP, SPACE } from "@/shared/constants/tokens";
import { useSafeBack } from "@/shared/hooks/use-safe-back";
import { TaskRow } from "@/features/student/components/task-row";
import { isOverdue } from "@/features/student/logic/format";
import { useTasks, useToggleTask } from "@/features/student/hooks/use-tasks";
import type { Task } from "@/features/student/types/student";

const FILTERS = ["Today", "Upcoming", "Overdue", "Done"] as const;
type Filter = (typeof FILTERS)[number];

const isToday = (iso: string) => new Date(iso).toDateString() === new Date().toDateString();

function matches(task: Task, filter: Filter): boolean {
  if (filter === "Done") return task.done;
  if (task.done) return false;
  if (filter === "Overdue") return isOverdue(task.dueAt);
  if (filter === "Today") return isToday(task.dueAt);
  return !isOverdue(task.dueAt) && !isToday(task.dueAt);
}

export default function StudentTodo() {
  const router = useRouter();
  const goBack = useSafeBack("/student/home");
  const { data, loading, error, refetch } = useTasks();
  const toggleTask = useToggleTask();
  const [filter, setFilter] = useState<Filter>("Today");
  const [descending, setDescending] = useState(false);

  const doneCount = (data ?? []).filter((t) => t.done).length;

  const filtered = useMemo(() => {
    const list = (data ?? []).filter((t) => matches(t, filter));
    return [...list].sort((a, b) => (descending ? b.dueAt.localeCompare(a.dueAt) : a.dueAt.localeCompare(b.dueAt)));
  }, [data, filter, descending]);

  return (
    <Screen role="student" scroll={false} scope="student/todo">
      <OfflineBanner />
      <PageTitle title="To-do" onBack={goBack} />
      <ProgressBar
        value={data?.length ? doneCount / data.length : 0}
        label={`${doneCount}/${data?.length ?? 0} done`}
      />
      <View style={{ flexDirection: "row", alignItems: "center", gap: SPACE.sm }}>
        <View style={{ flex: 1 }}>
          <SegmentedTabs items={FILTERS} value={filter} onChange={setFilter} />
        </View>
        <Pressable
          onPress={() => setDescending((d) => !d)}
          hitSlop={HIT_SLOP}
          accessibilityRole="button"
          accessibilityLabel={descending ? "Sort soonest first" : "Sort latest first"}
        >
          <Icon name={descending ? "arrow-down-outline" : "arrow-up-outline"} size="lg" color={C.primaryDark} />
        </Pressable>
      </View>

      <View style={{ flex: 1 }}>
        <ListState
          loading={loading}
          error={error}
          empty={!loading && filtered.length === 0}
          onRetry={refetch}
          emptyIcon="checkmark-done-outline"
          emptyTitle="Nothing here"
          emptyMessage="You're all caught up for this filter."
        >
          <FlatList
            data={filtered}
            keyExtractor={(t) => t.id}
            refreshing={loading}
            onRefresh={refetch}
            ItemSeparatorComponent={() => <View style={{ height: SPACE.md }} />}
            contentContainerStyle={{ paddingBottom: SPACE.xl }}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => (
              <TaskRow
                task={item}
                onToggle={() => void toggleTask.run(item.id)}
                onPress={() =>
                  router.push(
                    item.kind === "assignment"
                      ? { pathname: "/student/assignment-detail", params: { classId: item.classId, id: item.refId } }
                      : item.done
                        ? { pathname: "/student/quiz-result", params: { classId: item.classId, quizId: item.refId } }
                        : { pathname: "/student/quiz-take", params: { classId: item.classId, quizId: item.refId } },
                  )
                }
              />
            )}
          />
        </ListState>
      </View>
    </Screen>
  );
}
