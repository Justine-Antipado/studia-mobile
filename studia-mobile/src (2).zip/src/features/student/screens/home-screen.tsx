// home-screen.tsx — greeting, quick actions, today's tasks, upcoming deadlines, continue learning.
import { useRouter } from "expo-router";
import { Pressable, Text, View } from "react-native";

import { Icon, ListRow, OfflineBanner, QuickAction, SectionHeader } from "@/shared/components/ui";
import { Screen } from "@/shared/components/ui/screen";
import { C } from "@/shared/constants/studia-colors";
import { HIT_SLOP, SPACE, TYPE } from "@/shared/constants/tokens";
import { displayName, useRoleUser } from "@/core/data/storage/session-store";
import { ClassCard } from "@/features/student/components/class-card";
import { TaskRow } from "@/features/student/components/task-row";
import { dueLabel, isOverdue } from "@/features/student/logic/format";
import { useClasses } from "@/features/student/hooks/use-classes";
import { useTasks, useToggleTask } from "@/features/student/hooks/use-tasks";

const isToday = (iso: string) => new Date(iso).toDateString() === new Date().toDateString();

export default function StudentHome() {
  const user = useRoleUser("student");
  const router = useRouter();
  const classes = useClasses();
  const tasks = useTasks();
  const toggleTask = useToggleTask();

  const pending = (tasks.data ?? []).filter((t) => !t.done);
  const todayTasks = pending.filter((t) => isToday(t.dueAt) || isOverdue(t.dueAt)).slice(0, 3);
  const upcoming = pending.filter((t) => !todayTasks.includes(t)).slice(0, 3);
  const continueLearning = (classes.data ?? []).filter((c) => c.progress > 0 && c.progress < 1).slice(0, 2);

  return (
    <Screen role="student" scope="student/home" refreshing={tasks.loading} onRefresh={tasks.refetch}>
      <OfflineBanner />

      <View style={{ flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" }}>
        <View>
          <Text style={TYPE.muted}>Good day</Text>
          <Text style={TYPE.h1}>{user ? displayName(user) : "Student"}</Text>
        </View>
        <Pressable
          onPress={() => router.push("/student/search")}
          hitSlop={HIT_SLOP}
          accessibilityRole="button"
          accessibilityLabel="Search"
        >
          <Icon name="search-outline" size="lg" color={C.primaryDark} />
        </Pressable>
      </View>

      <View style={{ flexDirection: "row", justifyContent: "space-between", flexWrap: "wrap", rowGap: 10 }}>
        <QuickAction icon="book-outline" label="My Courses" onPress={() => router.push("/student/courses")} />
        <QuickAction icon="checkbox-outline" label="To-do" onPress={() => router.push("/student/todo")} />
        <QuickAction icon="calendar-outline" label="Planner" tone="blue" onPress={() => router.push("/student/planner")} />
        <QuickAction icon="sparkles-outline" label="AI Assistant" tone="gold" onPress={() => router.push("/student/ai")} />
      </View>

      {todayTasks.length > 0 ? (
        <View style={{ gap: SPACE.md }}>
          <SectionHeader title="Today's tasks" action="View All" onAction={() => router.push("/student/todo")} />
          {todayTasks.map((task) => (
            <TaskRow
              key={task.id}
              task={task}
              onToggle={() => void toggleTask.run(task.id)}
              onPress={() =>
                router.push(
                  task.kind === "assignment"
                    ? { pathname: "/student/assignment-detail", params: { classId: task.classId, id: task.refId } }
                    : { pathname: "/student/quiz-take", params: { classId: task.classId, quizId: task.refId } },
                )
              }
            />
          ))}
        </View>
      ) : null}

      {upcoming.length > 0 ? (
        <View style={{ gap: SPACE.md }}>
          <SectionHeader title="Upcoming deadlines" action="View All" onAction={() => router.push("/student/todo")} />
          {upcoming.map((task) => (
            <ListRow
              key={task.id}
              icon={task.kind === "quiz" ? "help-circle-outline" : "document-text-outline"}
              title={task.title}
              subtitle={`${task.classCode} · ${dueLabel(task.dueAt)}`}
              onPress={() => router.push("/student/todo")}
            />
          ))}
        </View>
      ) : null}

      {continueLearning.length > 0 ? (
        <View style={{ gap: SPACE.md }}>
          <SectionHeader title="Continue Learning" action="View All" onAction={() => router.push("/student/courses")} />
          {continueLearning.map((c) => (
            <ClassCard
              key={c.id}
              item={c}
              onPress={() => router.push({ pathname: "/student/course-detail", params: { id: c.id } })}
            />
          ))}
        </View>
      ) : null}
    </Screen>
  );
}
