// validators.ts — input validation/sanitization for every student form. Repositories never
// receive raw, untrimmed or oversized input. Route params are validated separately in
// core/logic/route-params.ts.
import type { AttachmentKind } from "@/features/student/types/student";

export const JOIN_CODE_PATTERN = /^[A-Z0-9]{6}$/;

export function validateJoinCode(raw: string): string | null {
  const code = raw.trim().toUpperCase();
  if (!code) return "Enter a class code.";
  if (!JOIN_CODE_PATTERN.test(code)) return "Class codes are 6 letters or numbers.";
  return null;
}

export function validateCommentText(raw: string): string | null {
  const text = raw.trim();
  if (!text) return "Write a comment first.";
  if (text.length > 500) return "Comments are limited to 500 characters.";
  return null;
}

export function validateSubmissionText(raw: string, required: boolean): string | null {
  const text = raw.trim();
  if (required && !text) return "Add a short note or attach a file.";
  if (text.length > 4000) return "Keep this under 4000 characters.";
  return null;
}

export function validateEssayAnswer(raw: string): string | null {
  const text = raw.trim();
  if (text.length > 4000) return "Keep your answer under 4000 characters.";
  return null;
}

/** mp4/mov/pdf/ppt(x)/docx/images only, matching docs/UI-BRIEF's upload whitelist. */
export const ALLOWED_EXTENSIONS: Record<string, AttachmentKind> = {
  pdf: "pdf",
  doc: "doc",
  docx: "doc",
  ppt: "slide",
  pptx: "slide",
  mp4: "video",
  mov: "video",
  jpg: "image",
  jpeg: "image",
  png: "image",
};

export const MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024;

export type FileCandidate = { name: string; sizeBytes: number };

export function sanitizeFileName(name: string): string {
  return name.replace(/[^A-Za-z0-9 ._-]/g, "_").slice(0, 120);
}

export function validateFile(file: FileCandidate): { error: string | null; kind: AttachmentKind | null } {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const kind = ALLOWED_EXTENSIONS[ext] ?? null;
  if (!kind) return { error: "Allowed files: PDF, Word, PowerPoint, images, MP4 or MOV.", kind: null };
  if (file.sizeBytes > MAX_FILE_SIZE_BYTES) return { error: "File is larger than 50 MB.", kind: null };
  return { error: null, kind };
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
