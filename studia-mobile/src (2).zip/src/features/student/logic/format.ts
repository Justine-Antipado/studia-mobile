// format.ts — date/score/label helpers shared by every student screen.
import type { Tone } from "@/shared/constants/studia-colors";

export const PASSING_PERCENT = 75;

export function isOverdue(iso: string, now = Date.now()): boolean {
  return new Date(iso).getTime() < now;
}

export function timeAgo(iso: string, now = Date.now()): string {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return "";
  const mins = Math.floor(Math.max(0, now - t) / 60_000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

const DATE_OPTS: Intl.DateTimeFormatOptions = { month: "short", day: "numeric" };
const TIME_OPTS: Intl.DateTimeFormatOptions = { hour: "numeric", minute: "2-digit" };

export function dueLabel(iso: string, now = Date.now()): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const overdue = date.getTime() < now;
  const when = `${date.toLocaleDateString("en-PH", DATE_OPTS)}, ${date.toLocaleTimeString("en-PH", TIME_OPTS)}`;
  return overdue ? `Overdue · was due ${when}` : `Due ${when}`;
}

export const toPercent = (score: number, max: number) => (max > 0 ? Math.round((score / max) * 100) : 0);

export function scoreTone(percent: number): Tone {
  if (percent >= PASSING_PERCENT) return "green";
  if (percent >= 60) return "gold";
  return "red";
}

export function hourLabel(hour: number): string {
  const h = ((hour + 11) % 12) + 1;
  return `${h}${hour >= 12 ? "PM" : "AM"}`;
}

export function dayLabel(dayIso: string): string {
  const date = new Date(`${dayIso}T00:00:00`);
  return date.toLocaleDateString("en-PH", { weekday: "short", month: "short", day: "numeric" });
}

export function weekdayShort(dayIso: string): string {
  return new Date(`${dayIso}T00:00:00`).toLocaleDateString("en-PH", { weekday: "short" });
}
