# student logic

`validators.ts` — input validation/sanitization for every form (join code, comments, submission
text, file whitelist). `format.ts` — due date, score and planner label helpers shared by screens.
