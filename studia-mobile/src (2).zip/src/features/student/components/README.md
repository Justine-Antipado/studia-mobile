# student components

Shared pieces used by more than one student screen: `class-card`, `comment-row`,
`attachment-row`, `task-row`, `quiz-question-card` (take + review modes), `planner-block-card`,
`video-player` (the only place expo-video is used). `course-detail/` holds that screen's 5 tabs.
