// comment-row.tsx — one comment on an announcement. Only the author can delete their own.
import { memo } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { Avatar, Icon } from "@/shared/components/ui";
import { C } from "@/shared/constants/studia-colors";
import { HIT_SLOP, SPACE, TYPE } from "@/shared/constants/tokens";
import { timeAgo } from "@/features/student/logic/format";
import type { Comment } from "@/features/student/types/student";

export const CommentRow = memo(function CommentRow({
  comment,
  onDelete,
}: {
  comment: Comment;
  onDelete?: () => void;
}) {
  return (
    <View style={s.row}>
      <Avatar name={comment.author} size={32} />
      <View style={s.body}>
        <View style={s.head}>
          <Text style={TYPE.bodyStrong} numberOfLines={1}>
            {comment.author}
          </Text>
          <Text style={TYPE.caption}>{timeAgo(comment.postedAt)}</Text>
        </View>
        <Text style={TYPE.body}>{comment.text}</Text>
      </View>
      {comment.authorIsMe && onDelete ? (
        <Pressable onPress={onDelete} hitSlop={HIT_SLOP} accessibilityRole="button" accessibilityLabel="Delete comment">
          <Icon name="trash-outline" size="sm" color={C.muted} />
        </Pressable>
      ) : null}
    </View>
  );
});

const s = StyleSheet.create({
  row: { flexDirection: "row", gap: SPACE.sm + 2, alignItems: "flex-start" },
  body: { flex: 1, gap: 2 },
  head: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: SPACE.sm },
});
