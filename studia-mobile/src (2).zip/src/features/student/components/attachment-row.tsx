// attachment-row.tsx — one file chip (assignment brief, submitted file, lesson material).
import { memo } from "react";

import { ListRow } from "@/shared/components/ui";
import type { IconName } from "@/shared/components/ui/icon";
import type { Attachment, AttachmentKind } from "@/features/student/types/student";

const ICON_BY_KIND: Record<AttachmentKind, IconName> = {
  pdf: "document-text-outline",
  doc: "document-outline",
  slide: "easel-outline",
  video: "videocam-outline",
  image: "image-outline",
};

export const AttachmentRow = memo(function AttachmentRow({
  attachment,
  onPress,
}: {
  attachment: Attachment;
  onPress?: () => void;
}) {
  return (
    <ListRow
      icon={ICON_BY_KIND[attachment.kind]}
      title={attachment.name}
      subtitle={attachment.sizeLabel}
      onPress={onPress}
      flat
    />
  );
});
