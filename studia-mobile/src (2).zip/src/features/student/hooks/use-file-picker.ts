// use-file-picker.ts — pick + validate a file against the mime/extension whitelist before it
// ever reaches a repository. Used by assignment submission (and later, instructor uploads).
import * as DocumentPicker from "expo-document-picker";
import { useCallback, useState } from "react";

import { formatFileSize, sanitizeFileName, validateFile } from "@/features/student/logic/validators";
import type { Attachment } from "@/features/student/types/student";

const ALLOWED_MIME_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "video/mp4",
  "video/quicktime",
  "image/*",
];

export function useFilePicker() {
  const [error, setError] = useState<string | null>(null);

  const pick = useCallback(async (): Promise<Attachment | null> => {
    setError(null);
    const result = await DocumentPicker.getDocumentAsync({
      type: ALLOWED_MIME_TYPES,
      copyToCacheDirectory: true,
    });
    if (result.canceled || !result.assets?.[0]) return null;

    const asset = result.assets[0]!;
    const sizeBytes = asset.size ?? 0;
    const { error: validationError, kind } = validateFile({ name: asset.name, sizeBytes });
    if (validationError || !kind) {
      setError(validationError ?? "That file could not be used.");
      return null;
    }

    return {
      id: `file_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
      name: sanitizeFileName(asset.name),
      kind,
      sizeLabel: formatFileSize(sizeBytes),
    };
  }, []);

  return { pick, error };
}
