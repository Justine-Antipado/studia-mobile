// use-mutation.ts — writes. Never auto-retries (only reads do). Supports an optimistic cache
// edit that is rolled back automatically if the call fails, and invalidates the affected
// query keys on success so every screen reading them revalidates.
import { useCallback, useState } from "react";

import { toAppError, type AppError, type Result } from "@/core/data/errors/app-error";
import { queryCache } from "@/core/data/cache/query-cache";

export type MutationOptions<TArgs, TResult> = {
  /** Applied to the cache immediately; rolled back if the call fails. */
  optimistic?: { key: string; apply: (args: TArgs) => unknown };
  /** Key(s) to invalidate once the call succeeds. */
  invalidate?: (args: TArgs, result: TResult) => string | string[];
};

export type MutationState<TArgs, TResult> = {
  run: (args: TArgs) => Promise<Result<TResult>>;
  loading: boolean;
  error: AppError | null;
};

export function useMutation<TArgs, TResult>(
  mutate: (args: TArgs) => Promise<Result<TResult>>,
  options: MutationOptions<TArgs, TResult> = {},
): MutationState<TArgs, TResult> {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<AppError | null>(null);

  const run = useCallback(
    async (args: TArgs): Promise<Result<TResult>> => {
      setLoading(true);
      setError(null);

      const snapshot = options.optimistic ? queryCache.getEntry(options.optimistic.key)?.data : undefined;
      if (options.optimistic) options.optimistic.apply(args);

      try {
        const result = await mutate(args);
        if (!result.ok) {
          if (options.optimistic) queryCache.set(options.optimistic.key, snapshot, 0);
          setError(result.error);
          return result;
        }
        const keys = options.invalidate?.(args, result.value);
        (Array.isArray(keys) ? keys : keys ? [keys] : []).forEach((k) => queryCache.invalidate(k));
        return result;
      } catch (e) {
        if (options.optimistic) queryCache.set(options.optimistic.key, snapshot, 0);
        const appErr = toAppError(e);
        setError(appErr);
        return { ok: false, error: appErr };
      } finally {
        setLoading(false);
      }
    },
    // options is expected to hold stable closures from the calling hook
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [mutate],
  );

  return { run, loading, error };
}
