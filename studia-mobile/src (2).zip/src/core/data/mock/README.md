# core data mock

`mock-data.ts` — small cross-feature mock lists (course overview, notifications, AI chat seed).
Instructor mock data moved to `features/instructor/data/` in P3.
`mock-latency.ts` — `simulateLatency()` + `mockCall()` shared by every feature's mock repository
so loading/error states are real; failure rate is `MOCK_FAILURE_RATE` (DEV only).
