// route-params.ts — NEVER trust a route param. Deep links and cold starts can carry anything,
// so every id/number/enum coming from the URL is validated here before it reaches a repository.
import { useLocalSearchParams } from "expo-router";
import { useMemo } from "react";

/** Ids we generate: letters, digits, dash, underscore, 1..64 chars (no path or query chars). */
const ID_PATTERN = /^[A-Za-z0-9_-]{1,64}$/;

const first = (value: string | string[] | undefined): string | undefined =>
  Array.isArray(value) ? value[0] : value;

/** Returns the id only when it is well formed, otherwise null (screen shows "not found"). */
export function parseId(value: string | string[] | undefined): string | null {
  const raw = first(value)?.trim();
  return raw && ID_PATTERN.test(raw) ? raw : null;
}

export function parseInteger(
  value: string | string[] | undefined,
  { min = 0, max = Number.MAX_SAFE_INTEGER }: { min?: number; max?: number } = {},
): number | null {
  const raw = first(value)?.trim();
  if (!raw || !/^-?\d{1,15}$/.test(raw)) return null;
  const n = Number(raw);
  return n >= min && n <= max ? n : null;
}

/** Validates a param against a fixed set of allowed values (role, tab name, difficulty...). */
export function parseEnum<T extends string>(
  value: string | string[] | undefined,
  allowed: readonly T[],
): T | null {
  const raw = first(value)?.trim();
  return allowed.find((a) => a === raw) ?? null;
}

/** Plain text param (search query, prefilled title): trimmed, length-capped, no control chars. */
export function parseText(value: string | string[] | undefined, maxLength = 200): string {
  return (first(value) ?? "")
    .replace(/[\u0000-\u001F\u007F]/g, "")
    .trim()
    .slice(0, maxLength);
}

/**
 * Validated `id` of a detail route:
 *   const id = useRouteId();            // "c1" | null
 *   const { id, classId } = useRouteIds("id", "classId");
 */
export function useRouteId(name = "id"): string | null {
  const params = useLocalSearchParams();
  return useMemo(() => parseId(params[name]), [params, name]);
}

export function useRouteIds<K extends string>(...names: K[]): Record<K, string | null> {
  const params = useLocalSearchParams();
  const key = names.join(",");
  return useMemo(() => {
    const out = {} as Record<K, string | null>;
    for (const name of names) out[name] = parseId(params[name]);
    return out;
    // names is captured by `key` so the memo is stable across renders.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params, key]);
}
