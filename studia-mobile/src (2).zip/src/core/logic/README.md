# core logic

Cross-feature logic: `route-params.ts` (validate every deep-link param before use),
`use-role-guard.ts` (client-side role/session guard; real authorization stays on the backend),
`report-error.ts` (single error sink, no sensitive data).
