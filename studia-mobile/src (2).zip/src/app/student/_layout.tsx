// app/student/_layout.tsx — student tab group.
// Tabs keep each screen mounted (no refetch / no scroll loss on tab switch). Child routes are
// registered with href: null and highlight their parent tab through `also` (docs/ROUTE-MAP.md).
import { Tabs } from "expo-router";

import { TAB_SCREEN } from "@/core/config/transitions";
import { ErrorBoundary } from "@/shared/components/ui/error-boundary";
import { RoleGate } from "@/shared/components/ui/role-gate";
import { StudiaTabBar, type TabItem } from "@/shared/components/ui/studia-tab-bar";

const TABS: Record<string, TabItem> = {
  home: {
    label: "Home",
    icon: "home-outline",
    activeIcon: "home",
    also: ["todo", "planner", "search"],
  },
  courses: {
    label: "Courses",
    icon: "book-outline",
    activeIcon: "book",
    also: [
      "course-detail",
      "join-class",
      "announcement-detail",
      "lesson-viewer",
      "assignment-detail",
      "quiz-take",
      "quiz-result",
    ],
  },
  ai: {
    label: "AI",
    icon: "sparkles-outline",
    activeIcon: "sparkles",
    also: ["ai-summary", "ai-mind-map", "ai-flashcards"],
  },
  notifications: {
    label: "Alerts",
    icon: "notifications-outline",
    activeIcon: "notifications",
    badge: 2,
  },
  account: {
    label: "Account",
    icon: "person-outline",
    activeIcon: "person",
    also: [
      "edit-profile",
      "change-password",
      "notification-settings",
      "appearance",
      "language",
      "privacy-security",
      "help",
      "about",
    ],
  },
};



export default function StudentLayout() {
  return (
    <RoleGate role="student">
      <ErrorBoundary scope="student-group">
        <Tabs
          screenOptions={TAB_SCREEN}
          tabBar={(props) => <StudiaTabBar {...props} items={TABS} />}
        >
          <Tabs.Screen name="home" />
          <Tabs.Screen name="courses" />
          <Tabs.Screen name="ai" />
          <Tabs.Screen name="notifications" />
          <Tabs.Screen name="account" />

          {/* Non-tab routes: reachable only by navigation, parent tab stays highlighted. */}
          <Tabs.Screen name="course-detail" options={{ href: null }} />
          <Tabs.Screen name="todo" options={{ href: null }} />
          <Tabs.Screen name="planner" options={{ href: null }} />
          <Tabs.Screen name="search" options={{ href: null }} />
          <Tabs.Screen name="join-class" options={{ href: null }} />
          <Tabs.Screen name="announcement-detail" options={{ href: null }} />
          <Tabs.Screen name="lesson-viewer" options={{ href: null }} />
          <Tabs.Screen name="assignment-detail" options={{ href: null }} />
          <Tabs.Screen name="quiz-take" options={{ href: null }} />
          <Tabs.Screen name="quiz-result" options={{ href: null }} />
        </Tabs>
      </ErrorBoundary>
    </RoleGate>
  );
}
