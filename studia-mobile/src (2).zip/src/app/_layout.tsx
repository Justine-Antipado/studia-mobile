// app/_layout.tsx — root layout: Poppins loaded behind the splash screen (no font flicker),
// one ErrorBoundary around the whole app, Toast host, and the root Stack transitions.
import { SplashScreen, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";

import {
  Poppins_400Regular,
  Poppins_600SemiBold,
  Poppins_700Bold,
  useFonts,
} from "@expo-google-fonts/poppins";

import { STACK_ROOT, STACK_SUBPAGE } from "@/core/config/transitions";
import { reportError } from "@/core/logic/report-error";
import { ErrorBoundary } from "@/shared/components/ui/error-boundary";
import { ToastProvider } from "@/shared/components/ui/toast";

SplashScreen.preventAutoHideAsync();

// Logo and mascot are bundled statically (required in the components that use them), so they are
// available offline and need no fetch. P1b adds expo-asset preloading here if needed.

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Poppins_400Regular,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  const ready = fontsLoaded || !!fontError;

  useEffect(() => {
    if (fontError) reportError(fontError, { scope: "root-layout.useFonts" });
    if (ready) void SplashScreen.hideAsync();
  }, [ready, fontError]);

  const onReset = useCallback(() => {
    // P1b: clear the QueryCache here so "Try again" refetches instead of replaying bad data.
  }, []);

  if (!ready) return null;

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <ErrorBoundary scope="root" onReset={onReset}>
        <ToastProvider>
          <Stack screenOptions={STACK_ROOT}>
            <Stack.Screen name="index" />
            <Stack.Screen name="learn-more" options={STACK_SUBPAGE} />
            <Stack.Screen name="explore" options={STACK_SUBPAGE} />
            <Stack.Screen name="auth" options={STACK_SUBPAGE} />

            <Stack.Screen name="student" />
            <Stack.Screen name="instructor" />
          </Stack>
        </ToastProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
