// app/instructor/_layout.tsx — instructor tab group.
// Was a Stack + hand-rolled tab bar that used router.replace (every tab switch destroyed the
// history, so back dead-ended). Now a Tabs navigator like the student group: real back stack,
// screens stay mounted, child routes registered with href: null (docs/ROUTE-MAP.md).
import { Tabs } from "expo-router";

import { TAB_SCREEN } from "@/core/config/transitions";
import { ErrorBoundary } from "@/shared/components/ui/error-boundary";
import { RoleGate } from "@/shared/components/ui/role-gate";
import { StudiaTabBar, type TabItem } from "@/shared/components/ui/studia-tab-bar";

const TABS: Record<string, TabItem> = {
  home: { label: "Home", icon: "home-outline", activeIcon: "home", also: ["analytics", "search"] },
  classes: {
    label: "Classes",
    icon: "people-outline",
    activeIcon: "people",
    also: [
      "class-detail",
      "create-class",
      "post-announcement",
      "announcement-detail",
      "upload-material",
      "material-detail",
      "create-assignment",
      "assignment-detail",
      "student-detail",
    ],
  },
  assessments: {
    label: "Assess",
    icon: "clipboard-outline",
    activeIcon: "clipboard",
    also: ["create-quiz", "ai-quiz", "quiz-detail", "grading", "grade-submission", "gradebook"],
  },
  ai: { label: "AI", icon: "sparkles-outline", activeIcon: "sparkles" },
  notifications: {
    label: "Alerts",
    icon: "notifications-outline",
    activeIcon: "notifications",
    badge: 2,
  },
  account: {
    label: "Account",
    icon: "person-outline",
    activeIcon: "person",
    also: [
      "edit-profile",
      "change-password",
      "notification-settings",
      "appearance",
      "language",
      "privacy-security",
      "help",
      "about",
    ],
  },
};



export default function InstructorLayout() {
  return (
    <RoleGate role="instructor">
      <ErrorBoundary scope="instructor-group">
        <Tabs
          screenOptions={TAB_SCREEN}
          tabBar={(props) => <StudiaTabBar {...props} items={TABS} />}
        >
          <Tabs.Screen name="home" />
          <Tabs.Screen name="classes" />
          <Tabs.Screen name="assessments" />
          <Tabs.Screen name="ai" />
          <Tabs.Screen name="notifications" />
          <Tabs.Screen name="account" />

          {/* Non-tab routes: reachable only by navigation, parent tab stays highlighted. */}
          <Tabs.Screen name="analytics" options={{ href: null }} />
          <Tabs.Screen name="search" options={{ href: null }} />
          <Tabs.Screen name="class-detail" options={{ href: null }} />
          <Tabs.Screen name="create-class" options={{ href: null }} />
          <Tabs.Screen name="post-announcement" options={{ href: null }} />
          <Tabs.Screen name="announcement-detail" options={{ href: null }} />
          <Tabs.Screen name="upload-material" options={{ href: null }} />
          <Tabs.Screen name="material-detail" options={{ href: null }} />
          <Tabs.Screen name="create-assignment" options={{ href: null }} />
          <Tabs.Screen name="assignment-detail" options={{ href: null }} />
          <Tabs.Screen name="student-detail" options={{ href: null }} />
          <Tabs.Screen name="create-quiz" options={{ href: null }} />
          <Tabs.Screen name="ai-quiz" options={{ href: null }} />
          <Tabs.Screen name="quiz-detail" options={{ href: null }} />
          <Tabs.Screen name="grading" options={{ href: null }} />
          <Tabs.Screen name="grade-submission" options={{ href: null }} />
          <Tabs.Screen name="gradebook" options={{ href: null }} />
        </Tabs>
      </ErrorBoundary>
    </RoleGate>
  );
}
