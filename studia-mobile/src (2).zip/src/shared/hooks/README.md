# shared hooks

`use-safe-back` (v2: logical-parent fallback + Android hardware back + unsaved-changes block),
`use-responsive` (compact <360 / tablet >=600), `use-color-scheme`, `use-network` (NetInfo
online/offline), `use-draft-autosave` (generic local form draft, autosave/restore/clear).
