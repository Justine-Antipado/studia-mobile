// use-network.ts — connectivity for the offline banner and to disable/queue writes.
// Re-checks when the app returns to the foreground as well as on NetInfo events.
import NetInfo from "@react-native-community/netinfo";
import { useEffect, useState } from "react";
import { AppState } from "react-native";

export function useNetwork(): { isOnline: boolean } {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    const applyState = (connected: boolean | null) => setIsOnline(connected !== false);

    const unsubscribe = NetInfo.addEventListener((state) => applyState(state.isConnected));
    void NetInfo.fetch().then((state) => applyState(state.isConnected));

    const appStateSub = AppState.addEventListener("change", (next) => {
      if (next === "active") void NetInfo.fetch().then((state) => applyState(state.isConnected));
    });

    return () => {
      unsubscribe();
      appStateSub.remove();
    };
  }, []);

  return { isOnline };
}
