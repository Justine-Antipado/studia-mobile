// segmented-tabs.tsx — in-screen tab strip (Stream · Lessons · Tasks · Grades · People).
// Scrolls horizontally when the labels do not fit and keeps the selected item in view.
import { useCallback, useRef } from "react";
import { ScrollView, StyleSheet, type ScrollViewInstance } from "react-native";

import { Chip } from "@/shared/components/ui/chip";
import { SPACE } from "@/shared/constants/tokens";

type Props<T extends string> = {
  items: readonly T[];
  value: T;
  onChange: (value: T) => void;
  /** Horizontal padding of the parent screen, so the strip can bleed to the edges. */
  inset?: number;
};

export function SegmentedTabs<T extends string>({ items, value, onChange, inset = 18 }: Props<T>) {
  const ref = useRef<ScrollViewInstance>(null);

  const select = useCallback(
    (item: T, index: number) => {
      onChange(item);
      ref.current?.scrollTo({ x: Math.max(0, index * 96 - 48), animated: true });
    },
    [onChange],
  );

  return (
    <ScrollView
      ref={ref}
      horizontal
      showsHorizontalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      style={[s.scroll, { marginHorizontal: -inset }]}
      contentContainerStyle={[s.content, { paddingHorizontal: inset }]}
    >
      {items.map((item, index) => (
        <Chip
          key={item}
          label={item}
          selected={item === value}
          onPress={() => select(item, index)}
        />
      ))}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  scroll: { flexGrow: 0 },
  content: { gap: SPACE.sm, alignItems: "center" },
});
