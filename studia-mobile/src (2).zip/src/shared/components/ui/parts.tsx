// parts.tsx — COMPATIBILITY SHIM (shrinking, do not add to it).
// Every primitive now lives in its own file; this file only keeps the pre-P1 names working.
// New code imports from "@/shared/components/ui" (index.ts). P2/P3 migrate the call sites,
// then this file is deleted.
import type { ReactNode } from "react";
import { StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";

import { Badge } from "@/shared/components/ui/badge";
import { EmptyState as EmptyStateBase } from "@/shared/components/ui/empty-state";
import { IconTile, type IconName } from "@/shared/components/ui/icon";
import { ListRow } from "@/shared/components/ui/list-row";
import { SegmentedTabs } from "@/shared/components/ui/segmented-tabs";
import type { Tone } from "@/shared/constants/studia-colors";
import { SHADOW, TYPE } from "@/shared/constants/tokens";

export { ActionButton } from "@/shared/components/ui/action-button";
export { AiTag } from "@/shared/components/ui/ai-tag";
export { Avatar } from "@/shared/components/ui/avatar";
export { BackTitle } from "@/shared/components/ui/page-title";
export { ProgressBar } from "@/shared/components/ui/progress-bar";
export { QuickAction } from "@/shared/components/ui/quick-action";
export { SearchField } from "@/shared/components/ui/search-field";
export { SectionHeader } from "@/shared/components/ui/section-header";
export { StatCard } from "@/shared/components/ui/stat-card";
export type { IconName } from "@/shared/components/ui/icon";

/** @deprecated use SHADOW.card from shared/constants/tokens */
export const shadow = SHADOW.card;

/** @deprecated use TYPE from shared/constants/tokens */
export const t = StyleSheet.create({ h1: TYPE.h1, h2: TYPE.h2, muted: TYPE.muted });

/** @deprecated use IconTile */
export function IconBox({
  name,
  size = 46,
  bg,
  color,
}: {
  name: IconName;
  size?: number;
  bg?: string;
  color?: string;
}) {
  return <IconTile name={name} size={size} bg={bg} color={color} />;
}

/** @deprecated use ListRow */
export function ListCard({
  icon,
  title,
  eyebrow,
  meta,
  right,
  footer,
  iconBg,
  iconColor,
  onPress,
  style,
}: {
  icon: IconName;
  title: string;
  eyebrow?: string;
  meta?: string;
  right?: ReactNode;
  footer?: ReactNode;
  iconBg?: string;
  iconColor?: string;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <View style={style}>
      <ListRow
        icon={icon}
        title={title}
        eyebrow={eyebrow}
        subtitle={meta}
        trailing={right}
        footer={footer}
        iconBg={iconBg}
        iconColor={iconColor}
        onPress={onPress}
      />
    </View>
  );
}

/** @deprecated use SegmentedTabs */
export function TabChips({
  items,
  value,
  onChange,
}: {
  items: readonly string[];
  value: string;
  onChange: (v: string) => void;
}) {
  return <SegmentedTabs items={items} value={value} onChange={onChange} />;
}

/** @deprecated use EmptyState from shared/components/ui/empty-state */
export function EmptyState({ icon, title, sub }: { icon: IconName; title: string; sub: string }) {
  return <EmptyStateBase icon={icon} title={title} message={sub} />;
}

const PILL_TONE: Record<string, Tone> = {
  purple: "primary",
  orange: "orange",
  blue: "blue",
  green: "green",
  red: "red",
};

/** @deprecated use Badge */
export function Pill({ text, tone = "purple" }: { text: string; tone?: keyof typeof PILL_TONE }) {
  return <Badge label={text} tone={PILL_TONE[tone] ?? "primary"} />;
}
