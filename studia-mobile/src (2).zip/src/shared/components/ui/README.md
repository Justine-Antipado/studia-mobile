# shared components ui

Shared UI kit. Import from the barrel: `import { Card, ListRow, Badge } from "@/shared/components/ui"`.
One source of truth per primitive — `AppImage` is the only remote-image renderer and `Icon` the only icon entry point.
`parts.tsx` is the pre-P1 compatibility shim; it is being removed as screens migrate.
