# core logic
