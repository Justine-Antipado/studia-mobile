# core config
