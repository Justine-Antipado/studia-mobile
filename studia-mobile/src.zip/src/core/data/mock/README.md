# core data mock
