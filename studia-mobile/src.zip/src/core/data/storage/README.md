# core data storage
