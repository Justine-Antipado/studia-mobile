# shared constants
