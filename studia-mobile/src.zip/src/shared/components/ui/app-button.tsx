// app-button.tsx

import { Pressable, StyleSheet, Text, type PressableProps } from "react-native";

import { C } from "@/shared/constants/studia-colors";

type Variant = "primary" | "secondary";

type AppButtonProps = Omit<PressableProps, "children" | "style"> & {
  label: string;
  variant?: Variant;
};

export function AppButton({
  label,
  variant = "primary",
  disabled,
  ...rest
}: AppButtonProps) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled: !!disabled }}
      disabled={disabled}
      style={({ pressed }) => [
        s.base,
        s[variant],
        pressed && !disabled && s.pressed,
        disabled && s.disabled,
      ]}
      {...rest}
    >
      <Text
        style={[
          s.label,
          variant === "primary" ? s.labelPrimary : s.labelSecondary,
          disabled && s.labelDisabled,
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const s = StyleSheet.create({
  base: {
    borderRadius: 14,
    borderWidth: 1, // pareho sa dalawa para pantay ang taas
    borderColor: "transparent",
    paddingVertical: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  primary: {
    backgroundColor: C.primary,
    shadowColor: C.primaryDark,
    shadowOpacity: 0.3,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  secondary: {
    backgroundColor: C.lavenderSoft,
    borderColor: C.lavender,
  },
  pressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
  // Walang opacity dito: sa Android, may lumalabas na parihabang shadow kapag may opacity + elevation.
  disabled: {
    backgroundColor: C.lavenderSoft,
    borderColor: C.lavender,
    shadowOpacity: 0,
    elevation: 0,
  },
  label: { fontSize: 16, fontFamily: "Poppins_600SemiBold" },
  labelPrimary: { color: C.white },
  labelSecondary: { color: C.primaryDark },
  labelDisabled: { color: C.muted },
});
