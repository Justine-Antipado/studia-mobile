# student logic
